--Railway need NO coal
UPDATE Route_ResourceCosts SET BuildWithUnitCost=0 WHERE ResourceType='RESOURCE_COAL';

--Military Engineer unlock earlier
UPDATE Units SET PrereqTech='TECH_ENGINEERING' WHERE UnitType='UNIT_MILITARY_ENGINEER';

--New Route: State Highway
INSERT OR REPLACE INTO Types (Type, Kind) VALUES
('ROUTE_HIGHWAY', 'KIND_ROUTE');

INSERT OR REPLACE INTO Routes (RouteType, Name, Description, MovementCost, SupportsBridges, PlacementValue, PlacementRequiresRoutePresent, PlacementRequiresOwnedTile, PrereqEra) VALUES
('ROUTE_HIGHWAY', 'LOC_ROUTE_HIGHWAY_NAME', 'LOC_ROUTE_HIGHWAY_DESCRIPTION', 0.5, 1, 4, 0, 0, NULL);
INSERT OR REPLACE INTO Routes_XP2 (RouteType, BuildOnlyWithUnit, BuildWithUnitChargeCost, PrereqTech) VALUES
('ROUTE_HIGHWAY', '1', '0', 'TECH_HORSEBACK_RIDING');

INSERT OR REPLACE INTO Route_ValidBuildUnits (RouteType, UnitType) VALUES
('ROUTE_HIGHWAY', 'UNIT_MILITARY_ENGINEER');


INSERT INTO Route_ResourceCosts(RouteType, ResourceType, BuildWithUnitCost) VALUES
('ROUTE_HIGHWAY', 'RESOURCE_HORSES', '1');