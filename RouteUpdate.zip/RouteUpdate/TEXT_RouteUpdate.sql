-- Language: en_US
INSERT OR REPLACE INTO EnglishText (Tag,Text) VALUES
('LOC_ROUTE_HIGHWAY_NAME',
'State Highway'),
('LOC_ROUTE_HIGHWAY_DESCRIPTION',
'Can be constructed by Military Engineers. Improves [ICON_Movement] Movement speed of any unit moving from one road tile to another.');